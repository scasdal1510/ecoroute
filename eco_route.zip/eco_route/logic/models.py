from dataclasses import dataclass
from typing import Optional

@dataclass
class Vehicle:
    id_vehiculo: str
    model: str
    capacidad_bateria_total: float
    nivel_bateria_actual: float
    autonomia_maxima_km: int
    estado: str = "disponible"
    deleted_at: Optional[str] = None

@dataclass
class Entrega:
    id_entrega: str
    destino_coordenadas: str
    peso: float
    prioridad: int  # 1 (Alta), 2 (Media), 3 (Baja)
    ventana_horaria: str
    deleted_at: Optional[str] = None

@dataclass
class Ruta:
    id_ruta: str
    vehiculo_asignado: str
    consumo_estimado_bateria: float
    deleted_at: Optional[str] = None