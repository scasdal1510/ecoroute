from db.vehicle_repo import VehicleRepository

class RouteService:
    def __init__(self):
        self.repo = VehicleRepository()

    def create_route(self, id_ruta, id_vehiculo, consumo_estimado):
        # Regla de Negocio RN-02: Límite del 80%
        if consumo_estimado > 80:
            raise ValueError("Error: El consumo de la ruta excede el 80% de la batería (RN-02).")
        
        # Lógica para guardar la ruta en la DB...
        print(f"Ruta {id_ruta} creada exitosamente.")

    def get_available_vehicles(self):
        return self.repo.list_all()