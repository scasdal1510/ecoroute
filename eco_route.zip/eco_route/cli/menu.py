import os

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def main_menu():
    clear_screen()
    print("="*40)
    print("       ECOROUTE - SISTEMA DE GESTIÓN      ")
    print("="*40)
    print("1. [Vehículos] Ver y Registrar")
    print("2. [Rutas] Planificar Nueva Ruta (RN-02)")
    print("3. [Entregas] Listar Entregas")
    print("0. Salir")
    print("-"*40)
    return input("Seleccione una opción: ")

def get_vehicle_data():
    """Captura de datos para crear un vehículo (CU-01)"""
    print("\n--- Registro de Nuevo Vehículo ---")
    return {
        'id': input("ID Vehículo (ej: VAN-001): ").strip(),
        'model': input("Modelo/Marca: ").strip(),
        'capacidad': float(input("Capacidad Batería (kWh): ")),
        'nivel': float(input("Nivel Carga Inicial (%): ")),
        'autonomia': int(input("Autonomía Máxima (km): ")),
        'estado': 'disponible'
    }

def get_route_data():
    """Captura de datos para crear una ruta"""
    print("\n--- Planificación de Ruta ---")
    return {
        'id': input("Código de Ruta: ").strip(),
        'vehiculo': input("ID del Vehículo asignado: ").strip(),
        'consumo': float(input("Consumo estimado para este viaje (%): "))
    }