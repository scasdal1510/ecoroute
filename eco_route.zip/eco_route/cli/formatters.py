from tabulate import tabulate

def format_vehicle_table(vehicles_list):
    """Formatea la lista de vehículos en una tabla tipo grid."""
    if not vehicles_list:
        return "No hay vehículos registrados."
    
    headers = ["ID", "Modelo", "Bat. Total", "Carga %", "Autonomía (km)", "Estado"]
    # Extraemos solo los datos necesarios para la tabla
    data = [
        [v['id_vehiculo'], v['model'], v['capacidad_bateria_total'], 
         f"{v['nivel_bateria_actual']}%", v['autonomia_maxima_km'], v['estado'].upper()] 
        for v in vehicles_list
    ]
    return tabulate(data, headers=headers, tablefmt="grid")

def format_delivery_table(deliveries_list):
    """Formatea la lista de entregas."""
    if not deliveries_list:
        return "No hay entregas pendientes."
    
    headers = ["ID Entrega", "Destino", "Peso (kg)", "Prioridad", "Ventana"]
    data = [
        [d['id_entrega'], d['destino_coordenadas'], d['peso'], d['prioridad'], d['ventana_horaria']]
        for d in deliveries_list
    ]
    return tabulate(data, headers=headers, tablefmt="grid")