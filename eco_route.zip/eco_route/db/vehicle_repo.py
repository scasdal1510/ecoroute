from db.connection import get_connection
from datetime import datetime

class VehicleRepository:
    def add(self, v):
        conn = get_connection()
        cursor = conn.cursor()
        query = "INSERT INTO vehicles (id_vehiculo, model, capacidad_bateria_total, nivel_bateria_actual, autonomia_maxima_km, estado) VALUES (%s, %s, %s, %s, %s, %s)"
        cursor.execute(query, (v.id_vehiculo, v.model, v.capacidad_bateria_total, v.nivel_bateria_actual, v.autonomia_maxima_km, v.estado))
        conn.commit()
        cursor.close()
        conn.close()

    def list_all(self):
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        # Solo trae los que no han sido borrados (Soft Delete)
        cursor.execute("SELECT * FROM vehicles WHERE deleted_at IS NULL")
        res = cursor.fetchall()
        cursor.close()
        conn.close()
        return res

    def soft_delete(self, id_vehiculo):
        conn = get_connection()
        cursor = conn.cursor()
        query = "UPDATE vehicles SET deleted_at = %s WHERE id_vehiculo = %s"
        cursor.execute(query, (datetime.now(), id_vehiculo))
        conn.commit()
        cursor.close()
        conn.close()