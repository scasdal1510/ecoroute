# main.py
from logic.services import LogicAgent # El que te pasé antes
from cli.menu import main_menu, get_vehicle_data, get_route_data
from cli.formatters import format_vehicle_table
import sys

def start_app():
    logic = LogicAgent()
    
    while True:
        choice = main_menu()
        
        if choice == "1":
            # Listar y dar opción de añadir
            vehicles = logic.list_vehicles()
            print(format_vehicle_table(vehicles))
            
            sub_choice = input("\n¿Desea registrar uno nuevo? (s/n): ")
            if sub_choice.lower() == 's':
                try:
                    data = get_vehicle_data()
                    logic.add_vehicle(data)
                    print("\n[✔] Vehículo guardado con éxito.")
                except Exception as e:
                    print(f"\n[✘] Error: {e}")
                input("\nPresione Enter para continuar...")

        elif choice == "2":
            try:
                data = get_route_data()
                logic.add_ruta(data) # Aquí se valida la RN-02 (80% batería)
                print("\n[✔] Ruta aprobada y registrada.")
            except ValueError as ve:
                print(f"\n[!] REGLA DE NEGOCIO VIOLADA: {ve}")
            except Exception as e:
                print(f"\n[✘] Error: {e}")
            input("\nPresione Enter para continuar...")

        elif choice == "0":
            print("Cerrando sistema EcoRoute...")
            sys.exit()

if __name__ == "__main__":
    start_app()